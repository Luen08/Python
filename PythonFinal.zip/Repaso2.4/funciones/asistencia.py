from datetime import datetime
import random
from re import X
from funciones.base import usuarios
from funciones.base import asistencia
import time
yel = '\033[33m'
rsa = '\033[0;m'
red = '\033[31m'
blu = '\033[34m'
mag = '\033[35m'
cya = '\033[36m'
gre = '\033[32m'

def asistenciaUser(nom):
    if {} == asistencia[nom]["Junio"]:
        hora_marcada = datetime.now().strftime("%H:%M")
        hora_marcada = datetime.strptime(hora_marcada, "%H:%M").time()
        time.sleep(1)
        print(gre+'-------------------------------'+rsa)
        print(f"Marcaste a las: {hora_marcada}")

        tuhora = usuarios[nom]["Hora"]

        tuhora = datetime.strptime(tuhora,"%H:%M").time()

        print("tu hora de llegada es a las: ",tuhora)
        print(gre+'-------------------------------'+rsa)

        if tuhora.hour < hora_marcada.hour:
            res = hora_marcada.hour - tuhora.hour
            minutos = res * 60 
            if hora_marcada.minute == tuhora.minute:
                print(red+'--------------------------------------------------------'+rsa)
                print(f"Llegaste a una hora exacta y tardaste {minutos} minutos")
                print(red+'--------------------------------------------------------'+rsa)
                return minutos
            else:
                total = hora_marcada.minute + minutos
                print(red+'-------------------------------'+rsa)
                print(f"  Llegaste {total} minutos tarde")
                print(red+'-------------------------------'+rsa)
                return total

        elif tuhora.hour == hora_marcada.hour:
            if tuhora.minute == hora_marcada.minute:
                print(red+'------------------------------------------------'+rsa)
                print(f"Llegaste justo a las {tuhora.strftime('%H:%M')}")
                print(red+'------------------------------------------------'+rsa)
            else:
                print(red+'-------------------------------'+rsa)
                print("Son las 8 pero")
                total = hora_marcada.minute
                print(f"Llegaste {total} minutos tarde")
                print(red+'-------------------------------'+rsa)
                return total

        else:
            print(blu+'-------------------------------'+rsa)
            print("Llegaste antes")
            res = tuhora.hour - hora_marcada.hour
            min = res * 60
            p = 60 - hora_marcada.minute
            total = min + p - 60
            print(f"Llegaste {total} minutos antes")
            print(blu+'-------------------------------'+rsa)
            return total
    else:
        return False
        


def generarasistencia(nombre, tardanza):
    dias = datetime.now().date().day
    uni = {}
    for i in range(1,dias+1):
        rangomenor = 60 - tardanza
        rangomayor = 60 + tardanza
        minutos = random.randint(rangomenor,rangomayor)
        o = str(i)
        fechadehoy = o+"/06/2022"

        if minutos > 60:
            a = minutos - 60
            uni[fechadehoy] = a
            asistencia[nombre]["Junio"]= uni
            
            
        elif minutos == 60:
            a = 0
            uni[fechadehoy]=a
            asistencia[nombre]["Junio"]= uni
        else:
            a=0
            uni[fechadehoy]=a
            asistencia[nombre]["Junio"]= uni
        if i == dias:
            uni[fechadehoy] = tardanza
            asistencia[nombre]["Junio"] = uni
