


b=['a','b','c']
a=['d','e']
c=['f']

lista = {}
print("Tardones","No marcaron")


for i in b,a,c:
    for z in i:
        print(i[z])
        

'''
print(b[0],a[0])
print(b[1],a[1])
print(b[2],a[2])


for i in b:
    lista['tardones'] = b
for t in a:
    lista['puntual'] = a  
    
    
#print(lista['tardones'])

for z in lista['tardones']:
    for t in lista['puntual']:
        print(t,z)
'''
'''
def vertardones(): #dividir en tardones y los q esta vacio...
    a = list() #No tienen asistencia
    b = list() #Tardones
    c = list() #puntuales
    fecha = validarFecha()
    for d in asistencia.keys():
        if asistencia[d]["Junio"] == {}:
            a.append(d)
        else:
            for q in asistencia[d]["Junio"]:
                if q == fecha:
                    if asistencia[d]["Junio"][q] > 0:
                        b.append(d)
                        break
                    else:
                        c.append(d)
                
    print("{:<20}{:<20}{:<0}".format("Tardones","Puntuales","No marcaron"))
    for i in b,c,a:
        for y in i:
            print(y)
            print("{:<20}".format(y))
            '''